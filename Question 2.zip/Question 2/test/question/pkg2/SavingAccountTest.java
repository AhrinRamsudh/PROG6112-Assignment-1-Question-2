/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package question.pkg2;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Ahrin Ramsudh
 */

public class SavingAccountTest {
    private SavingAccount savingAccount;

    @BeforeEach
    public void setUp() {
        savingAccount = new SavingAccount("12345", 2000.0, 0.05);
    }

    @Test
    public void testDeposit() {
        savingAccount.deposit(500.0);
        assertEquals(2500.0, savingAccount.getBalance(), 0.01); // 2000 + 500 = 2500
    }

    @Test
    public void testWithdraw() {
        savingAccount.withdraw(500.0);
        assertEquals(1500.0, savingAccount.getBalance(), 0.01); // 2000 - 500 = 1500
    }

  
    @Test
    public void testAddInterest() {
        savingAccount.addInterest();
        assertEquals(2100.0, savingAccount.getBalance(), 0.01); // 2000 + (2000 * 0.05) = 2100
    }
}

