/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question.pkg2;

/**
 *
 * @author Ahrin Ramsudh
 */
public class BankAccount {
    
    //declaration   
    private String accountNumber;
    private double balance;

    //Bank Account
    public BankAccount(String accountNumber, double balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    // deposit
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited R" + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    // withdraw 
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn R" + amount);
        } else {
            System.out.println("Invalid withdrawal amount.");
        }
    }
    
  //balance
    public double getBalance() {
        return balance;
    }
}

