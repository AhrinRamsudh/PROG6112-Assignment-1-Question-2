/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package question.pkg2;

import java.util.Scanner;

/**
 *
 * @author Ahrin Ramsudh
 */

public class BankingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Simple Banking System");
        System.out.println("");

        // savings account
        SavingAccount savingsAccount = new SavingAccount("12345",2000.00, 0.05);

        while (true) {
            // main menu and choises 
            System.out.println("Main Menu:");
            System.out.println("");
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Check Balance");
            System.out.println("4. Add Interest");
            System.out.println("5. Exit");
            System.out.println("");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                
               
                case 1:
                    // prompt user to enter an amount to deposit
                    System.out.println("");
                    System.out.print("Enter deposit amount: ");
                    double depositAmount = scanner.nextDouble();
                    
                    // adds deposit to savings amount
                    savingsAccount.deposit(depositAmount);
                    break;

                case 2:
                    // prompt user to enter an amount to withdraw
                    System.out.println("");
                    System.out.print("Enter withdrawal amount: ");
                    double withdrawalAmount = scanner.nextDouble();
                    
                    // subtracts withdrawal from savings amount
                    savingsAccount.withdraw(withdrawalAmount);
                    break;

                case 3:
                    //shows balance
                    System.out.println("");
                    //shows balance with all deposits and withdrawals 
                    System.out.println("Balance: R" + savingsAccount.getBalance());
                    break;

                case 4:
                    // shows and adds interest of 0.05 ot savings account  
                    System.out.println("");
                    savingsAccount.addInterest();
                    break;

                case 5:
                    // exit 
                    System.out.println("");
                    System.out.println("Goodbye!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    
            }
        }
    }
}
   
